
public class Parametros {
	private String codigoUm;
	private String codigoDois;
	
	public String getCodigoUm() {
		return codigoUm;
	}
	
	public String getCodigoDois() {
		return codigoDois;
	}

}
