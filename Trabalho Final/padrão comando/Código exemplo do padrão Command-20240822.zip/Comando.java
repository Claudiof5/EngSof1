
public interface Comando {
	public void executar(Parametros parametros);
}
