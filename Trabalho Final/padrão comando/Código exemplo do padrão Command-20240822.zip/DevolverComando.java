
public class DevolverComando implements Comando {

	@Override
	public void executar(Parametros parametros) {
		// TODO Auto-generated method stub

	}

}
